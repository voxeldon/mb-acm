import { AcmData } from "./data";
import { VerifyData } from "./verify_data";
export { 
    AcmData,VerifyData
};